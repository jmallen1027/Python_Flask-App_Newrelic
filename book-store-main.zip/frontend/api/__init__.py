## Docker Services ###

#USER_API_URL = 'http://user-service-c:5001'
#BOOK_API_URL = 'http://book-service-c:5002'
#ORDER_API_URL = 'http://order-service-c:5003'

## Local Hosts Services ##
USER_API_URL = 'http://127.0.0.1:5001'
BOOK_API_URL = 'http://127.0.0.1:5002'
ORDER_API_URL = 'http://127.0.0.1:5003'

### Vairables for URLS for other Web-App Services